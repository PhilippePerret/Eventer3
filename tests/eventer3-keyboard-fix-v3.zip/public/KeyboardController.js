import LOG from './system/LOG.js'

export default class KeyboardController {

  constructor() {
    this.activeLister = null
    this.modeStack = []
    this.boundHandleKeyDown = event => this.handleKeyDown(event)
  }

  register(lister) {
    LOG.m(2, 'KeyboardController.register', { lister: lister?.id ?? null, type: lister?.type ?? null })
    this.activeLister = lister
  }

  observe() {
    LOG.m(2, 'KeyboardController.observe')
    document.addEventListener('keydown', this.boundHandleKeyDown)
  }

  handleKeyDown(event) {
    const mode = this.currentMode()
    LOG.m(3, 'KeyboardController.handleKeyDown', { key: event.key, mode: mode?.name ?? 'lister-navigation', activeLister: this.activeLister?.id ?? null })
    if (mode) return this.handleModeKeyDown(event, mode)
    return this.handleListerNavigation(event)
  }

  pushMode(mode) {
    LOG.m(2, 'KeyboardController.pushMode', { name: mode?.name ?? null })
    this.modeStack.push(mode)
  }

  popMode() {
    const mode = this.modeStack.pop()
    LOG.m(2, 'KeyboardController.popMode', { name: mode?.name ?? null })
    return mode
  }

  currentMode() {
    return this.modeStack[this.modeStack.length - 1] ?? null
  }

  enterItemEdition(mode) {
    this.pushMode({ ...mode, name: 'item-edition' })
    requestAnimationFrame(() => {
      mode.defaultInput.focus()
      mode.defaultInput.select()
      LOG.m(2, 'KeyboardController.enterItemEdition.focus', { field: mode.defaultInput.name })
    })
  }

  handleModeKeyDown(event, mode) {
    if (typeof mode.onKeyDown === 'function') return mode.onKeyDown(event, this)
  }

  handleListerNavigation(event) {
    if (!this.activeLister) return LOG.m(2, 'KeyboardController.handleListerNavigation.noActiveLister')
    switch (event.key) {
      case 'n':
        event.preventDefault()
        LOG.m(2, 'KeyboardController.createNewItem', { lister: this.activeLister.id, type: this.activeLister.type })
        this.activeLister.createNewItem()
        return
      case 'ArrowDown':
        event.preventDefault()
        if (event.metaKey) this.activeLister.moveSelectedItemDown()
        else this.activeLister.selectNextItem()
        return
      case 'ArrowUp':
        event.preventDefault()
        if (event.metaKey) this.activeLister.moveSelectedItemUp()
        else this.activeLister.selectPreviousItem()
        return
    }
  }

}
