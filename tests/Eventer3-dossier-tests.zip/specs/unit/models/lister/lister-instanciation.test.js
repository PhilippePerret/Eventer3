// import test from 'node:test'
// import assert from 'node:assert/strict'

// import Lister from '../../../Eventer3/public/classes/models/Lister.js'

// test('Lister peut être instancié', () => {

//   const lister = new Lister()

//   assert.ok(lister)

// })
