# lib/models/item.rb

require 'json'
require 'fileutils'

class Item

  class << self

    def create_minimal_data(data_dir, id, pos = 100)
      item = new(minimal_data(id))
      item.save(data_dir)
    end

  end

  attr_reader :data

  def initialize(data)
    @data = data
  end

  def id
    data[:id]
  end

  def save(data_dir)

    FileUtils.mkdir_p(data_dir)

    File.write(
      File.join(data_dir, "#{id}.json"),
      JSON.pretty_generate(data)
    )

  end

end