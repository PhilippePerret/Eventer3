# lib/models/project.rb

require_relative './item'

class Project < Item

  class << self

    def minimal_data(id)
      {
        id: id,
        title: 'Projet modèle'
      }
    end

  end

end