# lib/models/projects.rb

require_relative './Lister'
require_relative './project'

class Projects < Lister

  class << self

    def minimal_data
      {
        id: 'projects',
        title: 'Liste des projets',
        items: ['demo'],
        brins: ['b1'],
        persos: ['p1']
      }
    end

  end

  def create_minimal_item(data_dir)

    Project.create_minimal_data(
      data_dir,
      'demo',
      100
    )

  end

end