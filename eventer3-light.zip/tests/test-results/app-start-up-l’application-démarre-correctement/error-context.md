# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: app/start-up.spec.js >> l’application démarre correctement
- Location: specs/e2e/app/start-up.spec.js:9:6

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.project-list')
Expected: 1
Received: 2
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for locator('.project-list')
    14 × locator resolved to 2 elements
       - unexpected value "2"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - main [ref=e2]:
    - generic [ref=e4]:
      - generic [ref=e5]: "---"
      - generic [ref=e6]: modele
  - contentinfo "Raccourcis clavier" [ref=e7]
```

# Test source

```ts
  1  | import fs from 'node:fs/promises'
  2  | import path from 'node:path'
  3  | import { test, expect } from '../../e2e/__setup__.js'
  4  | 
  5  | const appRoot = path.resolve(process.cwd(), '..')
  6  | const dataDir = path.join(appRoot, 'data')
  7  | 
  8  | 
  9  | test.only('l’application démarre correctement', async ({ page }) => {
  10 |   page.on('pageerror', error => console.error(error))
  11 | 
  12 |   console.log('\n-> destruction du dossier data')
  13 |   await fs.rm(
  14 |     dataDir,
  15 |     { recursive: true, force: true }
  16 |   )
  17 | 
  18 |   await page.goto('/')
  19 |   await expect(page.locator('#main-panel')).toHaveCount(1)
  20 |   await expect(page.locator('#main-panel')).toHaveClass(/project-list/)
> 21 |   await expect(page.locator('.project-list')).toHaveCount(1)
     |                                               ^ Error: expect(locator).toHaveCount(expected) failed
  22 |   await expect(page.locator('.project-item')).toHaveCount(1)
  23 |   await expect(page.locator('.project-item').nth(0)).toContainText('Projet modèle')
  24 | 
  25 | })
```