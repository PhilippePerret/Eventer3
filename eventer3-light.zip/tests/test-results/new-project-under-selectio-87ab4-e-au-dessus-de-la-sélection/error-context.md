# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: new-project-under-selection.spec.js >> la touche n crée un nouveau projet vide au-dessus de la sélection
- Location: specs/e2e/new-project-under-selection.spec.js:6:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: locator('.project-item').nth(1).locator('input')
Expected: "Titre du nouveau projet"
Error: strict mode violation: locator('.project-item').nth(1).locator('input') resolved to 2 elements:
    1) <input type="text" name="title" class="project-item__title" placeholder="Titre du nouveau projet"/> aka getByRole('textbox', { name: 'Titre du nouveau projet' })
    2) <input name="id" type="text" class="project-item__id" placeholder="identifiant"/> aka getByRole('textbox', { name: 'identifiant' })

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for locator('.project-item').nth(1).locator('input')

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main [ref=e2]:
    - generic [ref=e3]:
      - generic [ref=e4]:
        - generic [ref=e5]: Projet A
        - generic [ref=e6]: project-a
      - generic [ref=e7]:
        - textbox "Titre du nouveau projet" [active] [ref=e8]
        - textbox "identifiant" [ref=e9]
      - generic [ref=e10]:
        - generic [ref=e11]: Projet B
        - generic [ref=e12]: project-b
      - generic [ref=e13]:
        - generic [ref=e14]: Projet C
        - generic [ref=e15]: project-c
  - contentinfo "Raccourcis clavier" [ref=e16]
```

# Test source

```ts
  1  | import { installFixtures } from '../../helpers/install-fixtures'
  2  | installFixtures('many-projects')
  3  | 
  4  | import { test, expect } from '@playwright/test'
  5  | 
  6  | test('la touche n crée un nouveau projet vide au-dessus de la sélection', async ({ page }) => {
  7  |   await page.goto('/')
  8  | 
  9  |   const items = page.locator('.project-item')
  10 | 
  11 |   await expect(items).toHaveCount(3)
  12 | 
  13 |   await page.keyboard.press('ArrowDown')
  14 |   await expect(items.nth(1)).toHaveClass(/selected/)
  15 | 
  16 |   await page.keyboard.press('n')
  17 | 
  18 |   await expect(items).toHaveCount(4)
  19 |   await expect(items.nth(0)).toContainText('Projet A')
  20 |   await expect(items.nth(1)).toHaveClass(/selected/)
> 21 |   await expect(items.nth(1).locator('input')).toHaveAttribute('placeholder', 'Titre du nouveau projet')
     |                                               ^ Error: expect(locator).toHaveAttribute(expected) failed
  22 |   await expect(items.nth(1).locator('input')).toHaveValue('')
  23 |   await expect(items.nth(2)).toContainText('Projet B')
  24 | })
```