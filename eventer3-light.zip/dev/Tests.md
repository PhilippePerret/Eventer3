# Eventer - tests à faire

- [x] S’assurer que la classe JS `Lister` existe et qu’on peut instancier un objet d’une classe qui en hérite.

- [x] S’assurer que la classe JS `Item` existe et qu’on peut instancier un objet d’une classe qui en hérite.

- [x] S’assurer que la méthode `Lister.sortItems` existe et qu’elle classe bien les items fournis

- [x] S’assurer que des données minimales existent toujours (un dossier `data` qui peut avoir été détruit — ne pas le créer après l’avoir mis de côté avec son contenu en production pour qu’il n’existe pas au début)

- [x] S’assurer, en cas de données minimales manquantes, qu’un projet démo est bien créé, avec un brin minimal, un personnage minimal et un event minimal. S’assurer de ça en testant le DOM, ce projet doit être affiché.

- [ ] S’assurer que les classes CSS soient bien affectées pour la liste des projets (bonnes classes `item` + `project_listing`, il y a `#main-panel.projects-listing .project-listing` à affecter, et `.project-listing__item `, `.project-listing__title`, `.project-listing__id`).

- [x] S’assurer que pour un projet (Project < Item), seul le titre (`title`) et l’identifiant (`id`) soient affichés dans la ligne de l’item (dans le DOM).

- [ ] S’assurer que la liste complète des projets s’affiche après en avoir créé 3 actifs et 1 non actif qui ne doit pas s’afficher.

- [ ] S’assurer que le style du listing des projets et propre à ce `Lister` et cet`Lister` seulement

- [ ] S’assurer que le premier projet (en haut du listing — faire trois projets pour ce test) est bien sélectionné

  Ça doit être le cas pour tous les lister

- [ ] S’assurer que les flèches haut/bas permettent de passer d’un projet à l’autre (Ça doit être le cas pour tous les listers, pour tous leurs events, donc => ne pas implémenter un comportement qui ne fonctionnerait que pour les projets !!!!)

- [ ] S’assurer que la flèche droite permet de RENTRER dans le projet (c’est-à-dire de voir son premier évènemencier — qui correspond à ses `events`) (idem = valable pour n’importe quel lister)

- [ ] S’assurer que la flèche gauche permet de revenir à la liste des projets (idem = valable pour n’importe quel lister)

- [ ] S’assurer que Cmd-flèche haut/bas permet de déplacer les projets (idem = valable pour n’importe quel lister)

- [ ] S’assurer que le déplacement des projets est persistant (idem = valable pour n’importe quel lister)

- [ ] S’assurer que la touche Enter permet de modifier le titre du projet courant ((idem = valable pour n’importe quel lister))

- [ ] S’assurer que la modification du titre est bien persistante (Ça doit être le cas pour tous les lister)

- [ ] S’assurer que la touche « n » permet de créer (provisoirement juste dans le DOM) un nouveau projet SOUS la sélection — ATTENTION, CONTRAIREMENT AUX ÉVÈNEMENCIERS « NORMAUX », LES PROJETS, QUI NÉCESSITERONT DE FAIRE DES FICHIERS ET DOSSERS DANS LE FINDER, REPORTERONT À UNE VRAIE CRÉATION LA CRÉATION, SEULEMENT SI UN NOM DE PROJET EST BIEN DONNÉ)

- [ ] 
