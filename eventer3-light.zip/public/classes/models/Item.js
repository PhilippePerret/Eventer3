import LOG from '../../system/LOG.js'

export default class Item {

  static get newItemPlaceholder() {
    return 'Titre du nouvel item'
  }

  static createEmpty() {
    return new this({ id: '', title: '' })
  }

  constructor(data = {}) {
    this.id = data.id ?? null
    this.title = data.title ?? ''
    this.hasLister = data.hasLister ?? false
    this.type = data.type ?? []
    this.color = data.color ?? null
    this.checked = data.checked ?? false
    this.pos = data.pos ?? 0
    this.state = data.state ?? 0
    this.duration = data.duration ?? null
    this.path = data.path ?? null
    this.created_at = data.created_at ?? null
    this.updated_at = data.updated_at ?? null
    this.badge = data.badge ?? null
    this.patronyme = data.patronyme ?? null
    this.fonction = data.fonction ?? null
  }

  createElement(type) {
    const itemElement = document.createElement('div')
    itemElement.classList.add('item')
    itemElement.classList.add(`${type}-item`)
    return itemElement
  }

  createInputFromElement(element, name, value, placeholder) {
    const input = document.createElement('input')
    input.name = name
    input.type = 'text'
    input.className = element.className
    input.value = value ?? ''
    input.placeholder = placeholder
    input.style.border = '0'
    input.style.outline = '0'
    input.style.background = 'transparent'
    input.style.color = 'inherit'
    input.style.font = 'inherit'
    input.style.padding = '0'
    input.style.margin = '0'
    input.style.width = '100%'
    input.style.minWidth = '0'
    input.style.appearance = 'none'
    return input
  }

  createEditorElement(type, keyboardController) {
    LOG.m(2, 'Item.createEditorElement', { type, hasKeyboardController: Boolean(keyboardController) })
    if (!keyboardController) throw new Error('Item.createEditorElement: keyboardController missing')
    if (typeof keyboardController.enterItemEdition !== 'function') throw new Error('Item.createEditorElement: keyboardController.enterItemEdition missing')
    const itemElement = this.createElement(type)
    if (typeof this.render === 'function') this.render(itemElement)
    const titleElement = itemElement.querySelector(`.${type}-item__title`)
    const idElement = itemElement.querySelector(`.${type}-item__id`)
    if (!titleElement) throw new Error(`Item.createEditorElement: .${type}-item__title missing`)
    if (!idElement) throw new Error(`Item.createEditorElement: .${type}-item__id missing`)
    const titleInput = this.createInputFromElement(titleElement, 'title', this.title, this.constructor.newItemPlaceholder)
    const idInput = this.createInputFromElement(idElement, 'id', this.id, 'identifiant')
    titleElement.replaceWith(titleInput)
    idElement.replaceWith(idInput)
    keyboardController.enterItemEdition({
      defaultInput: titleInput,
      focusNextField: activeElement => {
        if (activeElement === titleInput) idInput.focus()
        else titleInput.focus()
      },
      cancel: () => {
        LOG.m(2, 'Item edition cancelled')
        itemElement.remove()
      },
      commit: () => {
        this.title = titleInput.value.trim()
        this.id = idInput.value.trim()
        LOG.m(2, 'Item edition committed', { title: this.title, id: this.id })
        itemElement.innerHTML = ''
        if (typeof this.render === 'function') this.render(itemElement)
      }
    })
    return itemElement
  }

}
