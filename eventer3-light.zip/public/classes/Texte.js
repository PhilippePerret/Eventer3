export default class Texte {

}
