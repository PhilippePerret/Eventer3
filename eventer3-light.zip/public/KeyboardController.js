import LOG from './system/LOG.js'

export default class KeyboardController {

  constructor() {
    this.activeLister = null
    this.modeStack = []
  }

  register(lister) {
    LOG.m(2, 'Register lister', lister.id)
    this.activeLister = lister
  }

  observe() {
    document.addEventListener('keydown', event => this.handleKeyDown(event))
  }

  handleKeyDown(event) {
    const mode = this.getCurrentMode()
    if (mode?.name === 'item-edition') return this.handleItemEditionKeyDown(event, mode)
    return this.handleListerNavigation(event)
  }

  pushMode(mode) {
    LOG.m(3, 'Push keyboard mode', mode.name)
    this.modeStack.push(mode)
  }

  popMode() {
    const mode = this.modeStack.pop()
    LOG.m(3, 'Pop keyboard mode', mode?.name ?? null)
    return mode
  }

  getCurrentMode() {
    return this.modeStack[this.modeStack.length - 1] ?? null
  }

  enterItemEdition(mode) {
    this.pushMode({ ...mode, name: 'item-edition' })
    requestAnimationFrame(() => {
      mode.defaultInput.focus()
      mode.defaultInput.select()
      LOG.m(3, 'Item edition focused', mode.defaultInput.name)
    })
  }

  handleItemEditionKeyDown(event, mode) {
    LOG.m(3, 'Item edition key', event.key)
    switch (event.key) {
      case 'Tab':
        event.preventDefault()
        mode.focusNextField(document.activeElement)
        return
      case 'Escape':
        event.preventDefault()
        mode.cancel()
        this.popMode()
        return
      case 'Enter':
        event.preventDefault()
        mode.commit()
        this.popMode()
        return
    }
  }

  handleListerNavigation(event) {
    if (!this.activeLister) return
    LOG.m(3, 'Lister navigation key', event.key, { metaKey: event.metaKey, shiftKey: event.shiftKey, ctrlKey: event.ctrlKey })
    switch (event.key) {
      case 'n':
        event.preventDefault()
        LOG.m(2, 'Create new item from keyboard')
        this.activeLister.createNewItem()
        return
      case 'ArrowDown':
        event.preventDefault()
        if (event.metaKey) this.activeLister.moveSelectedItemDown()
        else this.activeLister.selectNextItem()
        return
      case 'ArrowUp':
        event.preventDefault()
        if (event.metaKey) this.activeLister.moveSelectedItemUp()
        else this.activeLister.selectPreviousItem()
        return
    }
  }

}
