export default class LOG {

  static level = 0

  static on(level = 1) {
    this.level = level
  }

  static off() {
    this.level = 0
  }

  static m(...args) {

    if (this.level === 0) return

    let messageLevel   = 1
    let message        = null
    let messagePayload = []

    if (typeof args[0] === 'number') {
      messageLevel = args[0]
      message = args[1]
      messagePayload = args.slice(2)
    } else {
      message = args[0]
      messagePayload = args.slice(1)
    }

    if (messageLevel > this.level) return

    const len = 4 - messageLevel
    var pref = '🥁'
    if ( len > 0 ) {
      while ( pref.length < len ) pref = pref + '🥁'
    }
    console.log(`${pref}`, message, ...messagePayload)

  }

static warn(...args) {
    console.warn(
      '%c[WARN]',
      'color:red;font-weight:bold;',
      ...args
    )
  }

  static w(...args) {
    this.warn(...args)
  }
}