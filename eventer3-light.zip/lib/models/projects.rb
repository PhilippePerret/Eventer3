require_relative './Lister'
require_relative './project'

class Projects < Lister

  class << self

    def minimal_data
      {
        id: 'projects',
        title: 'Liste des projets',
        type: 'project',
        item_ids: ['model'],
        perso_ids: [],
        brin_ids: [],
        lasts_id: { item: 1, brin: 0, perso: 0}
      }
    end

  end

  def create_minimal_items(data_dir)
    puts "[create_minimal_items] data_dir: #{data_dir}"
    json_file = File.join(data_dir, 'projects', '__items.json')
    IO.write(json_file, Item.minimal_data_items.to_json)
    puts "Fichier __items.json : #{IO.read(json_file)}" 
  end

end